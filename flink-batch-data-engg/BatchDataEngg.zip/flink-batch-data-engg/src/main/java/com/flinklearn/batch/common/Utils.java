package com.flinklearn.batch.common;

public  class Utils {

    public static void printHeader(String msg) {

        System.out.println("\n**************************************************************");
        System.out.println(msg);
        System.out.println("---------------------------------------------------------------");
    }
}
